  <!-- -------- START FOOTER 3 w/ COMPANY DESCRIPTION WITH LINKS & SOCIAL ICONS & COPYRIGHT ------- -->
  <footer class="footer py-5">
    <div class="container">
      <div class="row">
      
      <?php if(!auth()->user() || \Request::is('static-sign-up')): ?>
        <div class="row">
          <div class="col-8 mx-auto text-center mt-1">
            <p class="mb-0 text-secondary">
              Copyright © <script>
                document.write(new Date().getFullYear())
              </script> Soft by 
              <a style="color: #252f40;" href="#" class="font-weight-bold ml-1" target="_blank">Degia Parlopa</a>
              &
              <a style="color: #252f40;" href="https://www.updivision.com" class="font-weight-bold ml-1" target="_blank">IT Teams</a>.
            </p>
          </div>
        </div>
      <?php endif; ?>
    </div>
  </footer>
  <!-- -------- END FOOTER 3 w/ COMPANY DESCRIPTION WITH LINKS & SOCIAL ICONS & COPYRIGHT ------- -->
<?php /**PATH C:\xampp\htdocs\asgo\resources\views/layouts/footers/guest/footer.blade.php ENDPATH**/ ?>